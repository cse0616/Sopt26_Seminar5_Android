package com.example.sopt26seminar5

data class CouponBtnData(
    val menu : String
)