package com.example.sopt26seminar5

data class CouponData(
    val menu : String,
    val name : String,
    val price : Int,
    val price_origin : Int,
    val date : String,
    val img_menu : String
)